package com.api.client_2.feign_client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.api.client_2.model.Students;

@FeignClient(url="http://localhost:1212/student",value = "studentService")
 
public interface StudentInterface {
	@RequestMapping(method = RequestMethod.GET)
	public ResponseEntity<List<Students>>getAllStudents();
	@RequestMapping(method = RequestMethod.GET,value="/{rollNo}")
	public ResponseEntity<List<Students>>getStudentByRollNo(@PathVariable int rllNo);
	@RequestMapping(method = RequestMethod.POST)
	public ResponseEntity<Students>saveStudents(@RequestBody Students student);



}
