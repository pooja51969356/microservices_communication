package com.api.client_2.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.api.client_2.feign_client.StudentInterface;
import com.api.client_2.model.Students;

@RestController
@RequestMapping("/parent")
public class ParentController {
@Autowired
StudentInterface studentInterface;

@RequestMapping(method = RequestMethod.GET)
public ResponseEntity<List<Students>> grtAllDetails(){
	return studentInterface.getAllStudents();
	}

@RequestMapping(method = RequestMethod.POST)
public ResponseEntity<Students>saveStudents(@RequestBody Students student){
	
	return  studentInterface.saveStudents(student);
}
}
