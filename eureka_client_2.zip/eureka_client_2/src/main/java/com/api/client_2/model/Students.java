package com.api.client_2.model;



import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Students {
private int rollNo;
private String studentsName;
private String standard;
private String section;
}
