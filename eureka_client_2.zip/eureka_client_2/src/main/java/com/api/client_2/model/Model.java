package com.api.client_2.model;

public class Model {

}
