package com.api.client.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.api.client.entity.Students;
import com.api.client.repository.StudentRepository;
@Service
public class StudentService {
 @Autowired
 StudentRepository repository;
	public List<Students> getAllStudent() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	public Students saveStudent(Students student) {
		// TODO Auto-generated method stub
		return  repository.save(student);
	}

}
