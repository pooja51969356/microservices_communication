package com.api.client.controlller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.api.client.entity.Students;
import com.api.client.service.StudentService;

@RestController
@RequestMapping(value = "/student")
public class StudentController {
@Autowired
StudentService  service;
@RequestMapping(method = RequestMethod.GET)
public ResponseEntity<List<Students>>getAllStudents(){
	
	return new ResponseEntity<>(service.getAllStudent(),HttpStatus.OK);	

}
@RequestMapping(method = RequestMethod.POST)
public ResponseEntity<Students>saveStudents(@RequestBody Students student){
	return new ResponseEntity<>(service.saveStudent(student),HttpStatus.OK);		
}




}
