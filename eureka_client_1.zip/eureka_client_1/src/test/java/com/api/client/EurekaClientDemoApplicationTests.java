package com.api.client;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaClientDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
